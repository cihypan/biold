This AIML set was written by Dr. Richard Wallace. This is the same AIML used to power the original A.L.I.C.E.

The AIML files were very slightly modified so they would work with Program E.