<?
include "curconv3.php";

$d = new curconv();
$money=$d -> uang("usa","indonesia",1);
echo $money;
?>