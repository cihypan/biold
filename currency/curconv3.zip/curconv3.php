<?php
/* Dadan Ramdan
 CurConv release 3.0
 License : Free
 thenewhiking@yahoo.com
 USD for USA
 IDR for Indonesian
 -- history Software --
 release 3.0
 modification from Jeffrey Hill script, www.flash-db.com
 release 2.0
 Modification from v1.0 becoming class
 release 1.0
 modification from METEO live v1.0 by Martin Bolduc
*/

class curconv {


	function uang($from,$to,$amount) {	
		$curval1 	= $from;
		$curval2 	= $to;
		$amount		 	= $amount;


		require_once('nusoap.php');


		$params1 = array(
			'country1' 		=> $from, 
			'country2' 		=> $to
		);	


		$sslient 		= new soapclient('Currency.wsdl','wsdl');

		$result 			= $sslient->call('getRate',$params1);

		$hasil= ($amount * $result);
		return $hasil;
	}
}
?>